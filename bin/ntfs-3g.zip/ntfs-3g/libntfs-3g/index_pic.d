index_pic.o index_pic.o: index.c ../config.h \
  /home/alessio/rg-5.4/rg/pkg/include/libc_config.h \
  /home/alessio/rg-5.4/rg/pkg/include/rg_def.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/include/rg_config.h \
  /home/alessio/rg-5.4/rg/pkg/include/os_includes.h \
  /home/alessio/rg-5.4/rg/pkg/include/rg_os.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/endian.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/features.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/uClibc_config.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/uClibc_arch_features.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/cdefs.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/endian.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/string.h \
  /usr/local/openrg/mips-brcm-linux-uclibc/bin/../lib/gcc/mips-linux-uclibc/4.2.3/include/stddef.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/include/util/util.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/param.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/limits.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/limits.h \
  /usr/local/openrg/mips-brcm-linux-uclibc/bin/../lib/gcc/mips-linux-uclibc/4.2.3/include/limits.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/posix1_lim.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/local_lim.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/linux/limits.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/uClibc_local_lim.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/posix2_lim.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/xopen_lim.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/stdio_lim.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/linux/param.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/asm/param.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/types.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/types.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/wordsize.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/kernel_types.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/typesizes.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/pthreadtypes.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/sched.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/time.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/select.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/select.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/sigset.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/time.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/sysmacros.h \
  /home/alessio/rg-5.4/rg/pkg/include/rg_types.h \
  /home/alessio/rg-5.4/rg/pkg/include/cc_config.h \
  /home/alessio/rg-5.4/rg/pkg/include/libc_config_include.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/libc_config_int.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/stdlib.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/waitflags.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/waitstatus.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/alloca.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/errno.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/errno.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/errno_values.h \
  ../include/ntfs-3g/attrib.h ../include/ntfs-3g/types.h ../config.h \
  ../include/ntfs-3g/inode.h ../include/ntfs-3g/layout.h \
  ../include/ntfs-3g/endians.h ../include/ntfs-3g/support.h \
  ../include/ntfs-3g/volume.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/stdio.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/uClibc_stdio.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/wchar.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/wchar.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/uClibc_mutex.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/pthread.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sched.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/uClibc_clk_tck.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/signal.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/initspin.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/sigthread.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/uClibc_pthread.h \
  /usr/local/openrg/mips-brcm-linux-uclibc/bin/../lib/gcc/mips-linux-uclibc/4.2.3/include/stdarg.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/mount.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/ioctl.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/ioctls.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/asm/ioctls.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/asm/ioctl.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/ioctl-types.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/ttydefaults.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/mntent.h \
  /home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/paths.h \
  ../include/ntfs-3g/device.h ../include/ntfs-3g/device_io.h \
  ../include/ntfs-3g/attrib.h ../include/ntfs-3g/unistr.h \
  ../include/ntfs-3g/runlist.h ../include/ntfs-3g/debug.h \
  ../include/ntfs-3g/logging.h ../include/ntfs-3g/collate.h \
  ../include/ntfs-3g/debug.h ../include/ntfs-3g/index.h \
  ../include/ntfs-3g/mft.h ../include/ntfs-3g/mst.h \
  ../include/ntfs-3g/dir.h ../include/ntfs-3g/logging.h \
  ../include/ntfs-3g/bitmap.h ../include/ntfs-3g/misc.h

../config.h:

/home/alessio/rg-5.4/rg/pkg/include/libc_config.h:

/home/alessio/rg-5.4/rg/pkg/include/rg_def.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/include/rg_config.h:

/home/alessio/rg-5.4/rg/pkg/include/os_includes.h:

/home/alessio/rg-5.4/rg/pkg/include/rg_os.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/endian.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/features.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/uClibc_config.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/uClibc_arch_features.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/cdefs.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/endian.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/string.h:

/usr/local/openrg/mips-brcm-linux-uclibc/bin/../lib/gcc/mips-linux-uclibc/4.2.3/include/stddef.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/include/util/util.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/param.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/limits.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/limits.h:

/usr/local/openrg/mips-brcm-linux-uclibc/bin/../lib/gcc/mips-linux-uclibc/4.2.3/include/limits.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/posix1_lim.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/local_lim.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/linux/limits.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/uClibc_local_lim.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/posix2_lim.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/xopen_lim.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/stdio_lim.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/linux/param.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/asm/param.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/types.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/types.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/wordsize.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/kernel_types.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/typesizes.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/pthreadtypes.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/sched.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/time.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/select.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/select.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/sigset.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/time.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/sysmacros.h:

/home/alessio/rg-5.4/rg/pkg/include/rg_types.h:

/home/alessio/rg-5.4/rg/pkg/include/cc_config.h:

/home/alessio/rg-5.4/rg/pkg/include/libc_config_include.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/libc_config_int.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/stdlib.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/waitflags.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/waitstatus.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/alloca.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/errno.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/errno.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/errno_values.h:

../include/ntfs-3g/attrib.h:

../include/ntfs-3g/types.h:

../config.h:

../include/ntfs-3g/inode.h:

../include/ntfs-3g/layout.h:

../include/ntfs-3g/endians.h:

../include/ntfs-3g/support.h:

../include/ntfs-3g/volume.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/stdio.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/uClibc_stdio.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/wchar.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/wchar.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/uClibc_mutex.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/pthread.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sched.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/uClibc_clk_tck.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/signal.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/initspin.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/sigthread.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/uClibc_pthread.h:

/usr/local/openrg/mips-brcm-linux-uclibc/bin/../lib/gcc/mips-linux-uclibc/4.2.3/include/stdarg.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/mount.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/ioctl.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/ioctls.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/asm/ioctls.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/asm/ioctl.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/ulibc/include/bits/ioctl-types.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/sys/ttydefaults.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/mntent.h:

/home/alessio/rg-5.4/rg/build.VOX_1.5_IT/pkg/build/ulibc/include/paths.h:

../include/ntfs-3g/device.h:

../include/ntfs-3g/device_io.h:

../include/ntfs-3g/attrib.h:

../include/ntfs-3g/unistr.h:

../include/ntfs-3g/runlist.h:

../include/ntfs-3g/debug.h:

../include/ntfs-3g/logging.h:

../include/ntfs-3g/collate.h:

../include/ntfs-3g/debug.h:

../include/ntfs-3g/index.h:

../include/ntfs-3g/mft.h:

../include/ntfs-3g/mst.h:

../include/ntfs-3g/dir.h:

../include/ntfs-3g/logging.h:

../include/ntfs-3g/bitmap.h:

../include/ntfs-3g/misc.h:
